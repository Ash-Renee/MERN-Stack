import logo from './logo.svg';
import './App.css';

function App() {
  return (
  <>
  <h1>Hello my fellow Transbians!</h1>
  <p>Welcome to the shit show!</p>
  <br/>
  <br/>
  <h2>Here is a list of random things my lazy ass is never gonna do:</h2>
  <tr>
    <th>Name</th>
    <th>Reason</th>
  </tr>
  <tr>
    <td>Climb Mt Everest</td>
    <td>Fuck that</td>
  </tr>
  <tr>
    <td>Punch Mark Zuckerburg</td>
    <td>Because I'm poor</td>
  </tr>
  <tr>
    <td>Be a stripper</td>
    <td>Bad knees</td>
  </tr>

  </>

  );
}

export default App;
