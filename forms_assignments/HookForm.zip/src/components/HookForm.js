import React, { useState } from 'react'

const HookForm = () => {
    const [firstName, setfirstName] = useState("");
    const [lastName, setlastName] = useState("");
    const [email, setemail] = useState("");
    const [password, setpassword] = useState("");
    const [formSubmitted, setformSubmitted] = useState(false);  //add one for each error field



    const submitHandler = theThingThatHappens => {
        theThingThatHappens.preventDefault();  //never forget this line otherwise your family will be cursed for 7 generations
        setformSubmitted(true);
    }
    return (
        <div>

            {
                formSubmitted ?  // ? IF
                <h2>Good job lab monkey {firstName} {lastName}</h2>
                :  // : then/else

            <form onSubmit={submitHandler}>
                <div>
                    <label htmlFor="firstName">First Name</label>
                    <input type="text" name="firstName" onChange={theThingThatHappens => setfirstName(theThingThatHappens.target.value)} />
                </div>

                <div>
                    <label htmlFor="lastName">Last Name</label>
                    <input type="text" name="lastName" onChange={theThingThatHappens => setlastName(theThingThatHappens.target.value)} />
                </div>

                <div>
                    <label htmlFor="email">Email</label>
                    <input type="text" name="email" onChange={theThingThatHappens => setemail(theThingThatHappens.target.value)} />
                </div>

                <div>
                    <label htmlFor="password">Password</label>
                    <input type="password" name="password" onChange={theThingThatHappens => setpassword(theThingThatHappens.target.value)} />
                </div>

                <div>
                    <label htmlFor="confirm_password">Confirm Password</label>
                    <input type="password" name="password" onChange={theThingThatHappens => setpassword(theThingThatHappens.target.value)} />
                </div>
                <div>
                <input type="submit" value="Submit" />
                </div>
            </form>
            }
            <p>First Name: {firstName}</p>
            <p>Last Name: {lastName}</p>
            <p>Email: {email}</p>
            <p>Password: {password}</p>
            <p>Confirm Password: {password}</p>
            </div>



    );
};

export default HookForm;
